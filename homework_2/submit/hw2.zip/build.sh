#!/bin/bash
cmake .
make
./hw2
