# HomeWork - 2
## By Kodur Krishna Chaitanya
Instruction to build:

1) run build.sh: ./build.sh
2) The lorenz attractor should run automatically

Directions to use:  
Press Keys:   
sigma: s(↑) a(↓),   
bias: b(↑) v(↓),   
rho: r(↑) e(↓)  

Time took to complete assignment: 2 days.

Thank you!