#!/bin/bash
cmake .
make
./hw4