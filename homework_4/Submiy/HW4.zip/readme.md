# HomeWork - 4
## By Kodur Krishna Chaitanya
Instruction to build:

1) run build.sh: ./build.sh
2) The hw4 executable should run automatically

Directions to use:  
Press "M" to change the view  
Press arrow keys to increase and decrease azimuth and elevation angle  
Press "x" to look the scenery through x axis  
Press "y" to look the scenery through y axis  
Press "z" to look the scenery through z axis  
Press "+" to move forward  
Press "-" to move backward 

Time took to complete assignment: 2 days.

Thank you!