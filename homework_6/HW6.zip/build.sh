#!/bin/bash
cmake .
make
./hw6