# HomeWork - 5
## By Kodur Krishna Chaitanya
Instruction to build:

1) Run build.sh: ./build.sh
2) The hw5 executable should run automatically

Directions to use:   
"+" : To zoom in  
"-" : To zoom out  
Arrow keys: To rotate the scene  
"m" : To pause the movement of light source   
"}" : Move light source Up  
"{" : Move light source down  

Thank you for your time!



 