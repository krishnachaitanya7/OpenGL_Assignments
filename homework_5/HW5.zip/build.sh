#!/bin/bash
cmake .
make
./hw5