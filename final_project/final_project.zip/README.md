# Final Project
## By Kodur Krishna Chaitanya
Instruction to build:

1) Run build.sh: ./build.sh
2) The final_project executable should run automatically

Directions to use:   
↑: To move up
↓: To move down

In the project The plane flies over a desert(Texture which can be changed, to be implemented
in the final submission), whenever it hits the mountainous surface collision is detected
and plane stops right there. Right now I am working on implementing smoke when collision happens.

Thank you for your time.



 