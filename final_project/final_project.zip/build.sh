#!/bin/bash
cmake .
make
./final_project